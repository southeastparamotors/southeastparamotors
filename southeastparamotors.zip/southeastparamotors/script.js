document.querySelector('.buy-now').addEventListener('click', () => {
  window.location.href = 'https://southeastparamotor.com'; // Update this with your preferred URL
});
